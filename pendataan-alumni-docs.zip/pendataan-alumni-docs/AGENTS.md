# AGENTS.md — Navigator untuk AI Agent

Proyek: **Sistem Pendataan Alumni** — website CRUD sederhana (PHP + MySQL + SB Admin 2), tanpa login, satu menu utama "Data Alumni".
Sumber kebenaran: dokumen RPD (`RPD_Sistem_Pendataan_Alumni.docx`). Seluruh isi `docs/` diturunkan dari RPD itu.

## Baca dulu (urutan wajib)

1. `docs/project.md` — apa yang dibangun, scope, stack, **apa yang TIDAK dibangun**
2. `docs/architecture.md` — struktur folder & alur request
3. `docs/coding-rules.md` — konvensi kode PHP/HTML/JS yang harus dipatuhi

## Peta dokumen

| Kebutuhan | Buka |
|---|---|
| Schema tabel `alumni`, SQL, data contoh | `docs/database.md` |
| Daftar halaman/endpoint, parameter, respons, redirect | `docs/routes-spec.md` |
| Alur kerja end-to-end (lihat, tambah, edit, hapus, cari) | `docs/workflow.md` |
| Wireframe teks & spesifikasi komponen SB Admin 2 | `docs/ui-design.md` |
| Kenapa keputusan teknis diambil | `docs/decisions.md` |
| Skenario uji & checklist manual | `docs/testing.md` |
| Instalasi XAMPP & troubleshooting | `docs/deployment.md` |
| Pekerjaan yang harus dikerjakan | `docs/tasks/task-00X-*.md` |

## Daftar task (kerjakan berurutan)

| # | File | Ringkasan | Bergantung pada |
|---|---|---|---|
| 001 | `tasks/task-001-project-setup.md` | Folder, database, `koneksi.php`, aset SB Admin 2 | — |
| 002 | `tasks/task-002-layout-template.md` | Layout bersama (header/sidebar/footer) + flash message | 001 |
| 003 | `tasks/task-003-read-and-search.md` | Tabel data alumni + pencarian | 002 |
| 004 | `tasks/task-004-create-alumni.md` | Form tambah + proses simpan | 003 |
| 005 | `tasks/task-005-update-alumni.md` | Form edit + proses update | 004 |
| 006 | `tasks/task-006-delete-alumni.md` | Hapus dengan konfirmasi | 003 |
| 007 | `tasks/task-007-validation-and-security.md` | Validasi sisi server/klien + pengamanan SQLi/XSS | 004, 005 |
| 008 | `tasks/task-008-testing-and-finalization.md` | Uji 7 skenario RPD, polish, dokumentasi | semua |

## Aturan keras (jangan dilanggar)

- **Tidak ada login/autentikasi.** Jangan menambah halaman login, session user, atau role. (RPD §A.7, §G)
- **Hanya satu menu sidebar: Data Alumni.** Tambah/Edit/Hapus/Cari adalah aksi, bukan menu. (RPD §A.8, §O)
- **Satu tabel: `alumni`** di database `db_alumni`. Jangan membuat tabel/relasi baru tanpa persetujuan.
- **Semua query pakai prepared statement.** Dilarang menyisipkan input langsung ke string SQL. (RPD §T)
- **Semua output ke HTML di-escape** dengan `e()`.
- **Stack: PHP native (tanpa framework), MySQL/MariaDB, SB Admin 2, HTML/CSS/JS.** Jangan memperkenalkan Laravel, React, Composer, atau build step.
- Di luar scope (RPD §G, §W): ekspor Excel/PDF, foto alumni, filter, statistik, backup, profil alumni, login. Jangan dikerjakan kecuali diminta eksplisit.

## Cara bekerja

1. Pilih task berikutnya yang belum selesai; baca "Dependensi" dan "Acceptance Criteria"-nya.
2. Ikuti `coding-rules.md`; cocokkan nama file/field persis dengan `architecture.md` dan `database.md`.
3. Setelah selesai, jalankan checklist di `testing.md` yang relevan, lalu centang Definition of Done di file task.
4. Bila ada konflik antar dokumen, urutan prioritas: **RPD > database.md > routes-spec.md > dokumen lain**. Catat keputusan baru di `decisions.md`.
